/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package uk.ac.aber.dcs.bpt.cs21120.assignment1;

/**
 * Get the indicated competition manager
 * @author bpt
 */
public class IManagerFactory {
    
    /**
     * Method to get the competition manager
     * @param className indicates the name of the class you would like returned, including full package name
     * @return returns an IManager
     */
    public static IManager getManager(String className) {
        
        Object obj;
        Object objd;
        IManager manager;
		try {
			obj = Class.forName(className).newInstance();
			//uncomment this out for one of the classes used.
			//pathname will need to be changed in run config too. 
			//obj = Class.forName("uk.ac.aber.dcs.nas29.cs21120.assignment1.SingleElimination").newInstance();
			//obj = Class.forName("uk.ac.aber.dcs.nas29.cs21120.assignment1.DoubleElimination").newInstance();
			//obj = Class.forName("uk.ac.aber.dcs.nas29.cs21120.assignment1.BubbleElimination").newInstance();
		//	
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}
		if (obj instanceof IManager) {
			manager = (IManager)obj;
			System.out.println("IManager selected successfully. ");
		} else {
			System.out.println(className + " is not a IManager. ");
			return null;
		}
		return manager;
    }
}
