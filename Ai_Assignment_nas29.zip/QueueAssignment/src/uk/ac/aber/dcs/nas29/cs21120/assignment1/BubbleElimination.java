package uk.ac.aber.dcs.nas29.cs21120.assignment1;

import java.util.ArrayList;

import uk.ac.aber.dcs.bpt.cs21120.assignment1.IManager;
import uk.ac.aber.dcs.bpt.cs21120.assignment1.Match;
import uk.ac.aber.dcs.bpt.cs21120.assignment1.NoNextMatchException;

public class BubbleElimination implements IManager {
	// private String p1,p2;
	private String player_1, player_2;
	private String[] thecompetitiongames;
	private Heap he;
	private Match m;
	private int teams;
	private boolean haswon;

	/*
	 * This method is adding the players to the heap.The heap is being
	 * instantiated and the amount of elements in the players arraylist is being
	 * added to the heap.While the competition array is storing the strings of
	 * the players and the size is being kept track of.
	 */
	@Override
	public void setPlayers(ArrayList<String> players) {
		he = new Heap(players.size());
		thecompetitiongames = new String[players.size()];
		for (String s : players) {
			thecompetitiongames[teams] = s;
			teams++;
		}
	}

	/*
	 * This method is comparing the amount of elements in the heap to the number
	 * of teams, if both are equal then there aren't any matchesbut if true
	 * there are still more matches to be played.
	 */
	@Override
	public boolean hasNextMatch() {
		if (he.getsize() == teams)
			return false;
		else
			return true;
	}

	/*
	 * This method returns the next match to play, this logic is getting player
	 * one and two, by using -1 this is getting the value of the playerif this
	 * -1 wasn't here null values would be returned. The else if the match isn't
	 * equal to true, then get another match which is in the last else block.
	 * Otherwise, create another match, as each child plays the parent until the
	 * parent has been beaten and the the player as at the front of theheap to
	 * be a winner.
	 */
	@Override
	public Match nextMatch() throws NoNextMatchException {
		if (he.getsize() == 0) {
			he.add(thecompetitiongames[he.getsize()]);
			player_2 = he.getPlayer(he.getsize() - 1);
			he.add(thecompetitiongames[he.getsize()]);
			player_1 = he.getPlayer(he.getsize() - 1);
		} else if (haswon != true) {
			he.add(thecompetitiongames[he.getsize()]);
			player_1 = he.getPlayer(he.getsize() - 1);
			player_2 = he.getParent(he.getPosition(player_1));
		} else
			player_2 = he.getParent(he.getPosition(player_1));
		return m = new Match(player_1, player_2);
	}

	/*
	 * 
	 * This sets the winner from the previous match
	 */
	@Override
	public void setMatchWinner(boolean player1) {
		if (player1 == true) {
			haswon = true;
			he.bubbleup(he.getPosition(player_1));
			if (he.getPosition(player_1) == 0) {
				haswon = false;
			}
		} else {
			haswon = false;
		}

	}

	/**
	 * Get the name of the player/team that finished in position n. The returned
	 * value should be null if the competition is still running, or if the
	 * competition hasn't determined who came in place n. e.g. a single
	 * elimination competition can only (validly) return the winner (n=0).
	 * 
	 * @param n
	 *            the position to return
	 * @return returns the name of the team/player, or null if competition still
	 *         running or n too large
	 */
	@Override
	public String getPosition(int n) {
		return he.getPlayer(n);
	}

}