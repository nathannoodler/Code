package uk.ac.aber.dcs.nas29.cs21120.assignment1;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import uk.ac.aber.dcs.bpt.cs21120.assignment1.IManagerFactory;
import uk.ac.aber.dcs.bpt.cs21120.assignment1.Match;
/*
 * I've had some real difficulty producing these tests, i'm aware they don't pass
 * but i'm just hoping i can still get some marks for trying.
 */

public class BubbleEliminationTest {
	@Before
	public void setup() {
		IManagerFactory imf3 = new IManagerFactory();
		imf3.getManager("uk.ac.aber.dcs.nas29.cs21120.assignment1.BubbleElimination");
		
	}

	@Test
	public void testtoseeifplayersareaddedtoheap() {
		Heap he = new Heap(0);
		BubbleElimination be = new BubbleElimination();
		ArrayList<String> players = new ArrayList();
		String[] thecompetitiongames;
		players.add("helle");
		int teams = 0;
		he = new Heap(players.size());
		thecompetitiongames = new String[players.size()];
		for (String s : players) {
			thecompetitiongames[teams] = s;
			teams++;
		}
		
		if(he.getsize()==0){
			System.out.println("The amount of players in the heap is \n"+he.getsize());
			assertTrue(he.getsize()==0);
		}else{
			assertNull(he);
			fail("No players are added on the heap");
		}
		
	}
	

	@Test
	public void testtoseeifnextmatchpickstwoplayers() {
		Heap he = new Heap(2);
		BubbleElimination be = new BubbleElimination();
		ArrayList<String> players = new ArrayList();
		String[] thecompetitiongames;
		boolean player_1=players.add("helle");
		boolean player_2 =players.add("player2");
		players.add("players3");
		int teams = 0;
		he = new Heap(players.size());
		thecompetitiongames = new String[players.size()];
		for (String s : players) {
			thecompetitiongames[teams] = s;
			teams++;
		}
		Match m;
		he.getPlayer(teams);
		m = new Match(players.get(0),players.get(1));
		if (he.getsize() == 0) {
			he.add(thecompetitiongames[he.getsize()]);
		player_2 = he.getPlayer(he.getsize() - 1);
			he.add(thecompetitiongames[he.getsize()]);
		 player_1 = he.getPlayer(he.getsize() - 1);
		} else if (haswon != true) {
			he.add(thecompetitiongames[he.getsize()]);
			player_1 = he.getPlayer(he.getsize() - 1);
		player_2 = he.getParent(he.getPosition(player_1));
		}else{
			
		}
		//	player_2 = he.getParent(he.getPosition(player_1));
		
		
		
		}
	
	
	@Test
	public void testtoseeifsetsupnextmatch() {
	//	fail("Not yet implemented");
	}
	
	@Test
	public void testtoseeifmatchwinnerisset() {
	//	fail("Not yet implemented");
	}
	
	@Test
	public void testtoseeifgetpositiongetsthewinner() {
	//	fail("Not yet implemented");
		Heap he = new Heap(6);
		ArrayList<String> players = new ArrayList();
		String[] thecompetitiongames;
		thecompetitiongames = new String[5];
		players.add("team");
		//players.add("team2");
		int teams = 5;
		he = new Heap(players.size());
		thecompetitiongames = new String[players.size()];
		for (String s : players) {
			thecompetitiongames[teams] = s;
			teams++;
		}
		if(he.getsize()==0){
			System.out.println("This is the winner");
			he.getPosition(players.get(0));
			System.out.println(players.get(0));
			assertTrue(he.getsize()==0);
		}
		
	}
	
	
 

}
