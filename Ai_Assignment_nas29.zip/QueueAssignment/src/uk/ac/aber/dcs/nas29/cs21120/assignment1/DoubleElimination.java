package uk.ac.aber.dcs.nas29.cs21120.assignment1;

import java.util.ArrayList;

import uk.ac.aber.dcs.bpt.cs21120.assignment1.IManager;
import uk.ac.aber.dcs.bpt.cs21120.assignment1.Match;
import uk.ac.aber.dcs.bpt.cs21120.assignment1.NoNextMatchException;

public class DoubleElimination implements IManager {
	// double queue in this area is actually the winner queue.
	// private WinnerQueue q;

	// private Queue q = new Queue(0);
	private Match m; // = new Match(null, null);
	private WinnerQueue wq;
	private String playerone;
	private String playertwo;
	private LoserQueue lq;
	private boolean matchCheckerf;

	// i think it will work like, wq.deQ a player then lq.enQ the player just
	// lost.
	// first result of the loser queue will be null, as ther eneeds to be
	// another losr to make a mathc.

	public DoubleElimination() {
	}

	/**
	 * Set the players or teams to use in the competition
	 * 
	 * @param players
	 *            the players or teams
	 */
	@Override
	public void setPlayers(ArrayList<String> players) {
		System.out.println(players);

		// this adds the players to the queue.
		int i = players.size();
		wq = new WinnerQueue(6);
		lq = new LoserQueue(6);
		lq.printQueue();
		for (String p : players) {
			wq.enQ(p);

			// this is fine
		}

	}

	// }
	/**
	 * Return true if there is another match in the competition that can be
	 * fetched using nextMatch
	 * 
	 * @return returns true if the competition is still going
	 */
	@Override
	public boolean hasNextMatch() {
		// if(nextMatch()==null){
		// yeah this conditon won't be forefilled because of the or
		if (wq.length() == 1 && lq.length() == 1) {

			return false;
		} else {

			return true;
		}
	}

	// this method stops a single player from being added to a match by
	// themselves.
	// this is correct.
	/**
	 * Returns the nextMatch to play
	 * 
	 * @return returns the next match
	 * @throws NoNextMatchException
	 *             if the competition is over and no more matches
	 */
	@Override
	public Match nextMatch() throws NoNextMatchException {
	
		if (wq.length() >= lq.length()) {
			playerone = (String) wq.deQ(); 
			playertwo = (String) wq.deQ();
			matchCheckerf = false;
			m = new Match(playerone, playertwo);
		} else {
			playerone = (String) lq.deQ(); 
			playertwo = (String) lq.deQ();
			m = new Match(playerone, playertwo);
			matchCheckerf = true;
		}
		return m;

		// get the palyers at the head of the queue then remove thme.

	}

	/**
	 * Sets the winner for the last retrieved Match
	 * 
	 * @param player1
	 *            should be true if player1 won the match, otherwise false
	 */
	@Override
	public void setMatchWinner(boolean player1) {

		if (player1 == true) {
			// if true it'll always add player one to the front this could be
			// the problem.
			wq.enQ(playerone);
			if (matchCheckerf == false) {
				lq.enQ(playertwo);
			}
		} else {
			wq.enQ(playertwo);
			if (matchCheckerf == false) {
				lq.enQ(playerone);
			}
		}
	}

	// this is correct.

	// so basically the two players are being removed from the queue and not
	// re-added.

	/**
	 * Get the name of the player/team that finished in position n. The returned
	 * value should be null if the competition is still running, or if the
	 * competition hasn't determined who came in place n. e.g. a single
	 * elimination competition can only (validly) return the winner (n=0).
	 * 
	 * @param n
	 *            the position to return
	 * @return returns the name of the team/player, or null if competition still
	 *         running or n too large
	 */
	@Override
	public String getPosition(int n) {
		// so this deals with the competition still running.
		// for this it's because the winner isn't going to the next match
		if (hasNextMatch() == true)
			return null;
		else if (n == 0)
			return (String) wq.getposition(wq.gethead());
		else
			return (String) lq.getposition(lq.gethead());
	}
}
