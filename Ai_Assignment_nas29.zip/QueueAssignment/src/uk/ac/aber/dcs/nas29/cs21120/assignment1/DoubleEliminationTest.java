package uk.ac.aber.dcs.nas29.cs21120.assignment1;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import uk.ac.aber.dcs.bpt.cs21120.assignment1.IManagerFactory;
import uk.ac.aber.dcs.bpt.cs21120.assignment1.Match;

public class DoubleEliminationTest {
	/*
	 * I've tried following the instructions set, but unable to get this to
	 * work.
	 */
	@Before
	public void setup() {
		IManagerFactory imf2 = new IManagerFactory();
		imf2.getManager("uk.ac.aber.dcs.nas29.cs21120.assignment1.DoubleElimination");
	}

	/*
	 * This tets to see if the players are added to the first queue, which is
	 * the winner q. I've created an instance of the Queue classbecause this
	 * class is the same as the winner and the loser queue. Minus the loser
	 * queeu not having the players added to it.
	 */
	@Test
	public void testsetplayerstoseeifadded() {
		DoubleElimination db = new DoubleElimination();

		ArrayList<String> players = new ArrayList();
		players.add("testname");
		Queue q1 = new Queue(1);
		q1.enQ(players);
		System.out.println("" + q1.length());
		if (q1.length() == 1) {
			assertTrue(q1.length() == 1);
		} //else {
			//assertNull(q1);
			//fail("The queue is empty, meaning players haven't been added to the arraylist players");
		}
		//assertFalse(q1.length() > 0);
//	}

	/*
	 * Tests the length of both queues, to see if both are equal to 1 then there
	 * can't be any more matches played
	 */
	@Test
	public void doublehasnextMatch() {
		Queue q1 = new Queue(4);
		Queue q2 = new Queue(6);
		ArrayList<String> players = new ArrayList();
		players.add("testname");
		players.add("testname2");
		q1.enQ(players);
		q2.enQ(players);
		if (q1.length() == 1 && q2.length() == 1) {
			boolean notmorematches = false;
			assertFalse(notmorematches);
			// returns zero because this condition is true.

		} else {
			System.out.println("There is a game being played");
		}

	}

	/*
	 * This test, actually sees if players are added to a match and when they
	 * can't bea dded to a match.
	 */
	@Test
	public void nextMatch() {
		Queue wq = new Queue(2);
		Queue lq = new Queue(2);
		ArrayList<String> players = new ArrayList();
		players.add("philip");
		players.add("alan");
		players.add("loser");
		wq.enQ(players);
		Match m;
		lq.enQ(players.get(0));
		lq.enQ(players.get(1));
		m = new Match(players.get(0), players.get(1));
		if (wq.length() >= lq.length()) {
			m = new Match(players.get(0), players.get(1));
			assertTrue(wq.length() >= lq.length());
			lq.deQ();
			lq.deQ();
		} else if (wq.length() >= lq.length()) {
			lq.enQ(players.get(0));
			lq.enQ(players.get(1));
			m = new Match(players.get(0), players.get(1));
			lq.deQ();
			lq.deQ();
			// set's up a loser match
		} else if (wq.length() == 0) {
			boolean queuehasawinner = false;
			assertFalse(wq.length() == 0);
		}
	}

	// need to look at this test.
	@Test
	public void setMatchWinner() {
		Queue wq = new Queue(1);
		Queue lq = new Queue(1);
		ArrayList<String> players = new ArrayList();
		SingleElimination s = new SingleElimination();
		players.add("Newcastle");
		wq.enQ(players.get(0));
		players.add("Manchester");
		Match m;

		lq.enQ(players.get(1));
		if (wq.length() == 0) {
			m = new Match(players.get(0), players.get(1));
			s.setMatchWinner(true);
			String player1 = players.get(0);
			String player2 = players.get(1);
			// i.e proves that the winner and loser arne't the same.
			// as it can be used in the get postion method too.
			assertNotSame(player1, player2);

		}
	}

	// This tests whether the winner is returned in the 0 position of the array.
	@Test
	public void getposition() {
		Queue wq = new Queue(2);
		Queue lq = new Queue(2);
		ArrayList<String> players = new ArrayList();
		SingleElimination s = new SingleElimination();
		players.add("Newcastle");
		wq.enQ(players);
		players.add("Manchester");
		lq.enQ(players);
		Match m;
		if (wq.length() <= 1) {
			System.out.println("The winner is:");
			System.out.println(players.get(1));

			System.out.println("The runner up is");
			System.out.print(players.get(0));
		} else if (players.size() == 0) {
			assertFalse(wq.isEmpty() || lq.isEmpty());
			fail("no players are in the queue");

		}

	}

}
