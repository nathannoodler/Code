package uk.ac.aber.dcs.nas29.cs21120.assignment1;
//Refrences from Bernie Tiddleman slides regarding getting parents and children. 
public class Heap {
	private String[] heap;
	private int size;
    /*
     * Intialises the array and the size. 
     */
	public Heap(int p) {

		heap = new String[p];
		size = 0;
	}
	 /*
     *
     * This intialises another string array of which if the size of i then incremenet i.
     * for the string array i passed in which is intlaised to the heap array.
     * These lines of code are making all of the arrays pointing to the heap array. 
     * The final lines are using the string array of which the size is being considered with the heap and then 
     * is being assinged to st and then the size is being incrememented. 
     * Essentially these lines of code keep track of the size of the heap, of which is compared to heap length. 
     */
	public void add(String st) {
		if (size == heap.length) {
			String[] str = new String[size * 2];
			for (int i = 0; i < size; i++) {
				str[i] = heap[i];
			}
			heap = str;
		}
		heap[size] = st;
		size++;

	}
    /*
     * Returns the size of the heap.
     */
	public int getsize() {
		return size;
	}
	 /*
     * Selects a player from the array using the for loop located above the str[i] = heap[i] line.
     */
	public String getPlayer(int i) {
		return heap[i];
	}
	 /*
     * This keeps track of the elements in the array in the form of a counter. If the if isn't forefilled
     * then null is returned suggesting that the array is empty.
     */
	public int getPosition(String st) {
		for (int i = 0; i < size; i++) {
			if (heap[i] == st) {
				return i;
			}
		}
		return (Integer) null;
	}
	// 
	 /*
     * This get's the parent of the child, i is referring to the position and the maths and get's the parent 
     * from the tree. 1-2/2 refers to the top of the tree.
     * .
     */
	public String getParent(int i) {
		return heap[((i - 2) / 2)];
	}
     
	/*
     * This get's left child, i is referring to the position and the maths and get's the left child
     * from the tree.
     * .
     */
	public String gettheleftchild(int i) {
		return heap[2 * i + 1];
	}
	/*
     * This get's right child, i is referring to the position and the maths and get's the right child
     * from the tree.
     * .
     */
	public String gettherightchild(int i) {
		return heap[2 * i + 2];
		// get's the right element within the binary tree
	}
     //Removes the winner from the heap.
	public void removeWinner() {
		heap[0] = heap[size];
		heap[size] = null;
		size--;
	}
	   //Bubble down will select the runner up in the process, after bubble up has finished and found the intial winner.
	public void bubbledown(int i, int i2) {
		String parent = heap[i];
		String child = heap[i2];
		heap[i] = child;
		heap[i2] = parent;
	}
    //This is when the children will enter a the end of the queue and will play the parent. If they win then they will be swapped with the loser.
	//The loser stays in the same location.
	public void bubbleup(int i) {
		String child = heap[i];
		String parent = heap[((i - 1) / 2)];
		heap[i] = parent;
		heap[((i - 1) / 2)] = child;
	}

}
