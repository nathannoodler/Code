package uk.ac.aber.dcs.nas29.cs21120.assignment1;
//Code is from Bernie Tiddleman slides on Queues and lists.
import java.util.Arrays;

public class LoserQueue {
	private Object[] loserqueue;
	private int tail, head, length;

	
	//The paramater allows a start size to be created so when calling the queue the number of elements 
		// expected by the queue can be set up.
	public LoserQueue(int startSize) {
		loserqueue = new Object[startSize];
		head = tail = length = 0;
	}

	// * This method adds an object to the back of the queue.
	public void enQ(Object o) {

		loserqueue[tail++] = o;
		length++;

		if (tail == loserqueue.length)
			tail = 0;
		printQueue();

	}

	// * Takes an object from the front of the queue.
	public Object deQ() throws QueueEmptyException {
	
		if (isEmpty())
			throw new QueueEmptyException(null);
		Object o = loserqueue[head];
		loserqueue[head] = null;
		head++;
		if (head == loserqueue.length)
			head = 0;
		length--;
		return o;

	}

	/*
	 *  inspects the object at the front of the queue, if the queue is empty then an exception is thrown 
	 *  if the queue is actually empty, making debugging easier.
	 */
	public Object front() throws QueueEmptyException {
		if (isEmpty())
			throw new QueueEmptyException(null);

		return loserqueue[head];

	}

	// * returns the size of the queue
	public int length() {
		return length;
		}

	// *checks if the queue is empty
	public boolean isEmpty() {

		if (loserqueue.length > 0) {
			// System.out.println("The queue isn't empty");
		} else {
			System.out.println("the queue is empty");
		}
		return false;
	}

	// System.out.println("Queue is empty");
	// return true;

	// *remove all objects from the queue.
	public void clear() {
		length = 0;
		loserqueue = new Object[loserqueue.length];
		head = tail = 0;
	}
	// Get's the element within the queue at position n this is used within the get position method in the 
		//single elimination class to retrieve the winner at 0, this is used with the head.
	public Object getposition(int n) {
		Object ol = loserqueue[n];
		return ol;
	}
	// Get's the front of the queue
	public int gethead() {
		return head;

	}

	public void printQueue() {
		System.out.println(Arrays.toString(loserqueue));
	}
}
