package uk.ac.aber.dcs.nas29.cs21120.assignment1;

import java.util.ArrayList;
import java.util.Arrays;
//Code is from Bernie Tiddleman slides on Queues and lists.
public class Queue {
	private Object[] queue;
	private int head, tail, length;


   //The paramater allows a start size to be created so when calling the queue the number of elements 
	// expected by the queue can be set up.
	public Queue(int startSize) {
		queue = new Object[startSize];
		head = tail = length = 0;
	}

	// * This method adds an object to the back of the queue.
	public void enQ(Object o) {

		queue[tail++] =o;
		length++;

		if (tail == queue.length)
			tail = 0;
		printQueue();

	}

	// * Takes an object from the front of the queue.
	public Object deQ() throws QueueEmptyException {
		if (isEmpty())
			throw new QueueEmptyException(null);
		Object o = queue[head];
		queue[head] = null;
		head++;
		if (head == queue.length)
			head = 0;
		length--;
		return o;

	}

	// * inspects the object at the front of the queue
	public Object front() throws QueueEmptyException {
		
		if (isEmpty())
			throw new QueueEmptyException(null);

		return queue[head];

	}

	// * returns the size of the queue
	public int length() {
		return length;
	}

	// *checks if the queue is empty
	public boolean isEmpty() {

		if (queue.length > 0) {
			
		} else {
			System.out.println("the queue is empty");
		}
		return false;
	}


	// *remove all objects from the queue.
	public void clear() {
		length = 0;
		queue = new Object[queue.length];
		head = tail = 0;
	}
    // Get's the element within the queue at position n this is used within the get position method in the 
	//single elimination class to retrieve the winner at 0, this is used with the head.
	public Object getposition(int n) {
		Object o1 = queue[n];
		return o1;
	}
// Get's the front of the queue
	public int gethead() {
		return head;

	}

	public void printQueue() {
		System.out.println(Arrays.toString(queue));
	}

}
