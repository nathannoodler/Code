package uk.ac.aber.dcs.nas29.cs21120.assignment1;

public class QueueEmptyException extends RuntimeException {

	public QueueEmptyException(String str) {
		super(str);
	}
}
