package uk.ac.aber.dcs.nas29.cs21120.assignment1;

import java.util.ArrayList;

import uk.ac.aber.dcs.bpt.cs21120.assignment1.CompetitionManager;
import uk.ac.aber.dcs.bpt.cs21120.assignment1.IManager;
import uk.ac.aber.dcs.bpt.cs21120.assignment1.Match;
import uk.ac.aber.dcs.bpt.cs21120.assignment1.NoNextMatchException;

public class SingleElimination implements IManager {

	// private Queue q = new Queue(0);
	private Match m; // = new Match(null, null);
	private Queue q;
	private String playerone;
	private String playertwo;

	// i think it will work like, wq.deQ a player then lq.enQ the player just
	// lost.
	// first result of the loser queue will be null, as ther eneeds to be
	// another losr to make a mathc.
    //default constructor for the Imanager test class.
	public SingleElimination() {
	}

	/**
	 * Set the players or teams to use in the competition
	 * This method adds all of the players from my text file into the my single queue.
	 * I set a size on my queue, for being above 4 just in case i get an out of bounds exception, as nulls may be added.
	 * @param players
	 *     
	 */
	@Override
	public void setPlayers(ArrayList<String> players) {
		System.out.println(players);
		// this adds the players to the queue.
		// int i = players.size();
		q = new Queue(6);
		for (String p : players) {
			q.enQ(p);
			// this is fine
		}

	}

	// }
	/**
	 * Return true if there is another match in the competition that can be
	 * fetched using nextMatch
	 * This method will prevent a player being added to match by themselves.
	 * so there can't be another game as there isn't enough players.While if is true, then another match will be played.
	 * @return returns true if the competition is still going
	 */
	@Override
	public boolean hasNextMatch() {
		// if(nextMatch()==null){
		if (q.length() == 1 || q.length() < 1) {
			return false;
		} else {
			return true;
		}
	}

	
	/**
	 * Returns the nextMatch to play
	 * This method will then set up the game, by getting the first and second player from the front of the queue and then pass them 
	 * into the match constructor. 
	 * @return returns the next match
	 * @throws NoNextMatchException
	 *             if the competition is over and no more matches
	 */
	@Override
	public Match nextMatch() throws NoNextMatchException {
		// So i'm getting the players from the front of the queue

		playerone = (String) q.deQ(); // q.getposition(numberofgamesplayed+0);

		playertwo = (String) q.deQ();
		m = new Match(playerone, playertwo);

		return m;

		// get the palyers at the head of the queue then remove thme.

	}

	/**
	 * Sets the winner for the last retrieved Match
	 * This method will send the winner to the back of the queue, meaning when the next match is played, the two other teams that haven't
	 * played one and other has a game then after this match the winner from the first match will play the winner from the previous game.
	 * @param player1
	 *            should be true if player1 won the match, otherwise false
	 */
	@Override
	public void setMatchWinner(boolean player1) {

		if (player1 == true) {

			q.enQ(playerone);
		} else {
			q.enQ(playertwo);

		}

	}

	// so basically the two players are being removed from the queue and not
	// re-added.

	/**
	 * Get the name of the player/team that finished in position n. The returned
	 * value should be null if the competition is still running, or if the
	 * competition hasn't determined who came in place n. e.g. a single
	 * elimination competition can only (validly) return the winner (n=0).
	 * The first statement ensures if a match is still running then null is returned if not then the winner is selected, this is 
	 * because no more matches are running.
	 * 
	 * @param n
	 *            the position to return
	 * @return returns the name of the team/player, or null if competition still
	 *         running or n too large
	 */
	@Override
	public String getPosition(int n) {
		// so this deals with the competition still running.
		// for this it's because the winner isn't going to the next match
		if (hasNextMatch() == true || n > 0) {
			return null;
		} else {
			return (String) q.getposition(q.gethead());
		}
	}

}
