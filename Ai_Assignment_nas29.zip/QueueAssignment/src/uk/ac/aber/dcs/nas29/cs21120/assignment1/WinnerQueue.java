package uk.ac.aber.dcs.nas29.cs21120.assignment1;

import java.util.Arrays;
//Code is from Bernie Tiddleman slides on Queues and lists.
public class WinnerQueue {
	private Object[] winnerqueue;
	// private Object[] loserqueue;
	private int head, tail, length;

	
	/*I've seperated both of the queues i have a winner queue class and a loser queue class, although there is duplication 
	 * i thought this is neater and more maintainable code.
	*/
	public WinnerQueue(int startSize) {
		winnerqueue = new Object[startSize];
		head = tail = length = 0;
	}

	// * This method adds an object to the back of the queue.
	public void enQ(Object o) {

		winnerqueue[tail++] = o;
		length++;

		if (tail == winnerqueue.length)
			tail = 0;
		printQueue();

	}

	// * Takes an object from the front of the queue.
	public Object deQ() throws QueueEmptyException {
	
		if (isEmpty())
			throw new QueueEmptyException(null);
		Object o = winnerqueue[head];
		winnerqueue[head] = null;
		head++;
		if (head == winnerqueue.length)
			head = 0;
		length--;
		return o;

	}

	// * inspects the object at the front of the queue
	public Object front() throws QueueEmptyException {
		// this is the issue, i think it's appling null to the value it's
		// dequuing.
		if (isEmpty())
			throw new QueueEmptyException(null);

		return winnerqueue[head];

	}

	// * returns the size of the queue
	public int length() {
		return length;
		// System.out.println("The size of the queue is" +queue.size());
		// return queue.size();

	}

	// *checks if the queue is empty
	public boolean isEmpty() {

		if (winnerqueue.length > 0) {
			
		} else {
			System.out.println("the queue is empty");
		}
		return false;
	}

	
	// *remove all objects from the queue.
	public void clear() {
		length = 0;
		winnerqueue = new Object[winnerqueue.length];
		head = tail = 0;
	}
	/*This method returns the winner from the queue this is related to the get position method, where the winner should be at the front of
	the queue, i.e n=0.
	*/
	public Object getposition(int n) {
		Object o1 = winnerqueue[n];
		return o1;
	}
	/*This method returns the team at the front of the queue
	*/
	public int gethead() {
		return head;

	}
		
	public void printQueue() {
		System.out.println(Arrays.toString(winnerqueue));
	}
}
